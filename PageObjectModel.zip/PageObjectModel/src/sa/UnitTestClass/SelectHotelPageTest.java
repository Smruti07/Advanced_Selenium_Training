package sa.UnitTestClass;

public class SelectHotelPageTest {

}
