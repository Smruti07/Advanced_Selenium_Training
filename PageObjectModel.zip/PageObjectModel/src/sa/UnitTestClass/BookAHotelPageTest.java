package sa.UnitTestClass;

public class BookAHotelPageTest {

}
