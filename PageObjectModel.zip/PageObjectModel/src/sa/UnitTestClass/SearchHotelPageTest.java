package sa.UnitTestClass;

public class SearchHotelPageTest {

}
